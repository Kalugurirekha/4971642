import java.util.HashMap;

public class Inventory {
    // HashMap to store products with productId as the key
    private HashMap<String, Product> productMap;

    // Constructor to initialize the HashMap
    public Inventory() {
        this.productMap = new HashMap<>();
    }

    // Method to add a product to the inventory
    public void addProduct(Product product) {
        productMap.put(product.getProductId(), product);
    }

    // Method to update a product in the inventory
    public void updateProduct(Product product) {
        productMap.put(product.getProductId(), product);
    }

    // Method to delete a product from the inventory
    public void deleteProduct(String productId) {
        productMap.remove(productId);
    }

    // Method to get a product by its productId
    public Product getProduct(String productId) {
        return productMap.get(productId);
    }
}
