public class InventoryManagementSystem {
    public static void main(String[] args) {
        // Create an inventory object
        Inventory inventory = new Inventory();

        // Create some products
        Product product1 = new Product("001", "Laptop", 10, 999.99);
        Product product2 = new Product("002", "Smartphone", 20, 499.99);
	
	System.out.println(product1);

        // Add products to the inventory
        inventory.addProduct(product1);
        inventory.addProduct(product2);

        // Update a product's quantity
        product1.setQuantity(15);
        inventory.updateProduct(product1);

        // Delete a product from the inventory
        inventory.deleteProduct("002");

        // Retrieve a product by its productId and print its name
        Product retrievedProduct = inventory.getProduct("001");
        System.out.println("Retrieved Product: " + retrievedProduct.getProductName());
    }
}
