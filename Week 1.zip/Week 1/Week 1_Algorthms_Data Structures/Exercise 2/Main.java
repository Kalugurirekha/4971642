public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product(1, "Laptop", "Electronics"),
            new Product(2, "Smartphone", "Electronics"),
            new Product(3, "Tablet", "Electronics"),
            new Product(4, "Headphones", "Accessories"),
            new Product(5, "Charger", "Accessories")
        };

        // Linear Search Example
        System.out.println("Linear Search:");
        Product result1 = LinearSearch.linearSearch(products, "Tablet");
        if (result1 != null) {
            System.out.println("Product found: " + result1);
        } else {
            System.out.println("Product not found.");
        }

        // Binary Search Example
        System.out.println("Binary Search:");
        Product result2 = BinarySearch.binarySearch(products, "Tablet");
        if (result2 != null) {
            System.out.println("Product found: " + result2);
        } else {
            System.out.println("Product not found.");
        }
    }
}
