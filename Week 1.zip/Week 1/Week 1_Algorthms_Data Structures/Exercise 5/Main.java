public class Main {
    public static void main(String[] args) {
        SinglyLinkedList taskList = new SinglyLinkedList();

        // Adding Tasks
        taskList.addTask(new Task(1, "Task 1", "Pending"));
        taskList.addTask(new Task(2, "Task 2", "Completed"));
        taskList.addTask(new Task(3, "Task 3", "In Progress"));

        // Traversing Tasks
        System.out.println("Tasks:");
        taskList.traverseTasks();

        // Searching for a Task
        System.out.println("Searching for Task with ID 2:");
        Task task = taskList.searchTask(2);
        if (task != null) {
            System.out.println("Task found: " + task);
        } else {
            System.out.println("Task not found.");
        }

        // Deleting a Task
        System.out.println("Deleting Task with ID 2:");
        taskList.deleteTask(2);

        // Traversing Tasks after Deletion
        System.out.println("Tasks after deletion:");
        taskList.traverseTasks();
    }
}
