public class MVCPatternExample {
    public static void main(String[] args) {
        // Create a Student model
        Student student = new Student("John Doe", "123", "A");

        // Create a Student view
        StudentView view = new StudentView();

        // Create a Student controller
        StudentController controller = new StudentController(student, view);

        // Display initial details
        controller.updateView();

        // Update student details
        controller.setStudentName("Jane Smith");
        controller.setStudentGrade("A+");

        // Display updated details
        controller.updateView();
    }
}
