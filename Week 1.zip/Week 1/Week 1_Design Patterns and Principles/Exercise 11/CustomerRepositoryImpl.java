public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public Customer findCustomerById(int id) {
        // For simplicity, we'll return a mock customer
        return new Customer(id, "John Doe");
    }
}
