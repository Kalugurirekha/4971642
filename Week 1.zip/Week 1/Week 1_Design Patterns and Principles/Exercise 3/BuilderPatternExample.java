public class BuilderPatternExample {
    public static void main(String[] args) {
        // Create a Computer using the Builder pattern
        Computer gamingComputer = new Computer.Builder()
            .setCPU("Intel Core i9")
            .setRAM("32GB")
            .setStorage("1TB SSD")
            .setGraphicsCard("NVIDIA GeForce RTX 3080")
            .setPowerSupply("750W")
            .setMotherboard("ASUS ROG Maximus XIII")
            .setCoolingSystem("Liquid Cooling")
            .build();

        Computer officeComputer = new Computer.Builder()
            .setCPU("Intel Core i5")
            .setRAM("16GB")
            .setStorage("512GB SSD")
            .setGraphicsCard("Integrated")
            .setPowerSupply("500W")
            .setMotherboard("MSI B450 TOMAHAWK")
            .setCoolingSystem("Air Cooling")
            .build();

        // Print the configurations
        System.out.println("Gaming Computer: " + gamingComputer);
        System.out.println("Office Computer: " + officeComputer);
    }
}
