// ProxyImage.java
public class Proxyimage implements Image {
    private Realimage realimage;
    private String fileName;

    public Proxyimage(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public void display() {
        if (realimage == null) {
            realimage = new Realimage(fileName);
        }
        realimage.display();
    }
}

