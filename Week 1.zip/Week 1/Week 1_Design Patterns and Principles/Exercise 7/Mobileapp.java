public class Mobileapp implements Observer {
    private String name;

    public Mobileapp(String name) {
        this.name = name;
    }

    @Override
    public void update(double stockPrice) {
        System.out.println("Mobile App " + name + ": Stock price updated to " + stockPrice);
    }
}
