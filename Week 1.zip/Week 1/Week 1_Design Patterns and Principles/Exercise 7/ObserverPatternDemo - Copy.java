public class ObserverPatternDemo {
    public static void main(String[] args) {
        Stockmarket stockMarket = new Stockmarket();

        Observer mobileApp1 = new Mobileapp("App1");
        Observer mobileApp2 = new Mobileapp("App2");
        Observer webApp1 = new WebApp("WebApp1");

        stockMarket.registerObserver(mobileApp1);
        stockMarket.registerObserver(mobileApp2);
        stockMarket.registerObserver(webApp1);

        stockMarket.setStockPrice(100.50);
        System.out.println("");

        stockMarket.setStockPrice(101.00);
        System.out.println("");

        stockMarket.removeObserver(mobileApp1);
        stockMarket.setStockPrice(102.75);
    }
}
