package com.example.EmployeeManagementSystem;

import com.example.employeemanagement.entity.Employee;
import com.example.employeemanagement.service.EmployeeService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;

@SpringBootTest
public class EmployeeServiceTest {

    @Autowired
    private EmployeeService employeeService;

    @Test
    public void testBatchInsert() {
        List<Employee> employees = new ArrayList<>();
        for (int i = 0; i < 50; i++) {
            Employee employee = new Employee();
            employee.setName("Employee " + i);
            employee.setActive(true);
            employees.add(employee);
        }
        employeeService.saveEmployees(employees);
    }
}

