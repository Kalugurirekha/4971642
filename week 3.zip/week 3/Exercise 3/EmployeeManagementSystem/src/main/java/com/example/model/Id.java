package com.example.model;

public @interface Id {
}
