package com.example.employeemanagementsystem.entity;

// src/main/java/com/example/ems/entity/Employee.java



import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name = "Employee.findByLastName", query = "SELECT e FROM Employee e WHERE e.lastName = :lastName")
public class Employee {

    @Id
    private Long id;
    private String firstName;
    private String lastName;
    private String email;

    // getters and setters
}

