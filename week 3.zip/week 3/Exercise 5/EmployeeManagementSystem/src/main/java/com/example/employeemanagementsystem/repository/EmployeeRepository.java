package com.example.employeemanagementsystem.repository;

// src/main/java/com/example/ems/repository/EmployeeRepository.java


import com.example.ems.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Custom query method using @Query annotation
    @Query("SELECT e FROM Employee e WHERE e.email = :email")
    List<Employee> findByEmail(@Param("email") String email);

    // Named query method
    List<Employee> findByLastName(@Param("lastName") String lastName);
}
