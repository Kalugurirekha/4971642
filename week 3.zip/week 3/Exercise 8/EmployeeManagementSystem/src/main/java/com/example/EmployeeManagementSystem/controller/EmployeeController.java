package com.example.EmployeeManagementSystem.controller;

import com.example.employeemanagement.dto.EmployeeDTO;
import com.example.employeemanagement.projection.EmployeeProjection;
import com.example.employeemanagement.service.EmployeeService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping("/projections")
    public List<EmployeeProjection> getAllEmployeeProjections() {
        return employeeService.getAllEmployeeProjections();
    }

    @GetMapping("/dtos")
    public List<EmployeeDTO> getAllEmployeeDTOs() {
        return employeeService.getAllEmployeeDTOs();
    }
}

