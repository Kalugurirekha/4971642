package com.example.EmployeeManagementSystem.repository;

import com.example.employeemanagement.entity.Employee;
import com.example.employeemanagement.projection.EmployeeProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EmployeeRepository<Employee> extends JpaRepository<Employee, Long> {

    @Query("SELECT e.name as name, e.position as position, d.name as departmentName FROM Employee e JOIN e.department d")
    List<EmployeeProjection> findAllEmployeeProjections();
}

