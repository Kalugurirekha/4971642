package com.example.EmployeeManagementSystem.secondary.repository;

import com.example.employeemanagement.secondary.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
}
