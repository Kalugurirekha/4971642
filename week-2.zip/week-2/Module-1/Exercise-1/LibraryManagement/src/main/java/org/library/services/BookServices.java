package org.library.services;

public class BookServices {
    BookServices()
    {
        System.out.println("BookServices obj is Created");
    }
}
