Scenario 1: Handle Exceptions During Fund Transfers Between Accounts
CREATE OR REPLACE PROCEDURE SafeTransferFunds(p_from_account_id NUMBER, p_to_account_id NUMBER, p_amount NUMBER) IS
BEGIN
    UPDATE Accounts
    SET Balance = Balance - p_amount
    WHERE AccountID = p_from_account_id;

    UPDATE Accounts
    SET Balance = Balance + p_amount
    WHERE AccountID = p_to_account_id;

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/


