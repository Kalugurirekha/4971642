Scenario 2: Compute the Monthly Installment for a Loan

CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment(p_loan_amount NUMBER, p_interest_rate NUMBER, p_duration_years NUMBER) RETURN NUMBER IS
    l_monthly_installment NUMBER;
BEGIN
    l_monthly_installment := (p_loan_amount * (1 + p_interest_rate / 100) / (p_duration_years * 12));
    RETURN l_monthly_installment;
END;
/
