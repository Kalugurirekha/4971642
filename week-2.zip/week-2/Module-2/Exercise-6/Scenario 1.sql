--Scenario 1: Generate Monthly Statements for All Customers

DECLARE
    CURSOR cur_transactions IS
        SELECT CustomerID, TransactionDate, Amount, TransactionType
        FROM Transactions
        WHERE TransactionDate BETWEEN TRUNC(SYSDATE, 'MM') AND LAST_DAY(SYSDATE);
BEGIN
    FOR txn IN cur_transactions LOOP
        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || txn.CustomerID || ', Date: ' || txn.TransactionDate || ', Amount: ' || txn.Amount || ', Type: ' || txn.TransactionType);
    END LOOP;
END;
/


