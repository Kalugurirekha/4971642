--Scenario 3: Update the Interest Rate for All Loans Based on a New Policy

DECLARE
    CURSOR cur_loans IS
        SELECT LoanID, InterestRate
        FROM Loans;
BEGIN
    FOR loan IN cur_loans LOOP
        UPDATE Loans
        SET InterestRate = loan.InterestRate * 1.05 -- Applying a 5% increase as an example
        WHERE LoanID = loan.LoanID;
    END LOOP;
    COMMIT;
END;
/